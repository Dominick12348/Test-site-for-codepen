# Activity 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/Dominick12348/pen/eYjbyJz](https://codepen.io/Dominick12348/pen/eYjbyJz).

